package de.tuhh.diss.harborstorage;

import de.tuhh.diss.harborstorage.sim.StorageElement;

public class Packet implements StorageElement{
	private int Width;
	private int Height;
	private int Depth;
	private int Weight;
	private String Description;
	private int ID;
	private double Location;
	//the private variables are created needed to define the packet along with the class packet using the storage element class
	public  Packet (int wi, int hi, int di, String des, int we){
		Width = wi;
		Height = hi;
		Depth = di;
		Weight = we;
		Description = des;
	}
	//here the variables from storage element class are tied to variables in packet class
	public int getWidth() {
		int wi = Width;
		return wi; //in each of these cases, methods are created for the packet class depending on which variables are needed. "own code" is
		//left to show were we edited code vs. what was supplied to us at the beginning of the lab. in most cases, the method returns the var
		// with the exception of the set location method . 
	}

	public int getHeight() {
		int hi = Height;
		return hi; // own code 
	}

	public int getDepth() {
		int di = Depth;
		return di; // own code 
	}

	public int getId() {
		int id = ID;
		return id; // own code
	}
	
	public void setId(int id) {
		ID = id;
		 // own code 
	}
	
	public String getDescription() {
		String des =Description;
		return des; //own code
	}
	public int getWeight() {
		int we = Weight;
		return we; // own code 
	}
	public double getLocation(){
		double loc = Location;
		return loc; // own code
	}
	public void setLocation(double loc){
		Location = loc; // own code
	}
}